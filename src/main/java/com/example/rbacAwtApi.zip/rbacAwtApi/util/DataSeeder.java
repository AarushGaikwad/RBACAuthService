package com.example.rbacAwtApi.util;

public class DataSeeder {
}
