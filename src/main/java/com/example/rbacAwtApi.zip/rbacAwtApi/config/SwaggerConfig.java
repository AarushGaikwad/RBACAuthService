package com.example.rbacAwtApi.config;

public class SwaggerConfig {
}
