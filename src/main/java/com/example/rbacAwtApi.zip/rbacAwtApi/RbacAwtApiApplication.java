package com.example.rbacAwtApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RbacAwtApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbacAwtApiApplication.class, args);
	}

}
