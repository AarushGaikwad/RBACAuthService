package com.example.rbacAwtApi.controller;

public class UserController {
}
