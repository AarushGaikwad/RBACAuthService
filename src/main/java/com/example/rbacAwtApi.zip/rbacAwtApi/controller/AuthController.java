package com.example.rbacAwtApi.controller;

public class AuthController {
}
